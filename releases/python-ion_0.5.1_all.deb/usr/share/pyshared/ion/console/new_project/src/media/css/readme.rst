Here you can put your css static files to be served by Ion.
