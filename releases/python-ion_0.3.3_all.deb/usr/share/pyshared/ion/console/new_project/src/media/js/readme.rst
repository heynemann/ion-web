Here you can put your javascript static files to be served by Ion.
