Here you can put your image static files to be served by Ion.
